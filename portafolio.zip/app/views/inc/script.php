<div id="scripts">
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/ajax.js"></script>
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/tooltip.js"></script>
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/Modal.js"></script>
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/dropdown.js"></script>
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/scroll.js"></script>
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/visited.js"></script>
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/cube.js"></script>
	<script type="text/javascript" src="<?php echo APP_URL; ?>app/views/js/viewMore.js"></script>
	<script src="https://platform.linkedin.com/badges/js/profile.js" async defer type="text/javascript"></script>
</div>