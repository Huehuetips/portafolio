
<section id="header about" class=" bg-dark text-white p-5">
    <div class="container"  id="about">

        
        <div class="row">
            <div class="col-md-2 div_foto">
                <img src="<?php echo APP_URL. "app/views/img/Foto.jpg"; ?>" class="FOTO" loading="lazy">
            </div>        
            <div class="col-md-10">
                <header class="jumbotron jumbotron-fluid " >
                    <div class="">
                        <h1 class="display-4 stroke"><?php echo NAME_ENG; ?></h1>
                    </div>
                    <p class="lead">Programador y Desarrollador Web Full Stack</p>
                </header>
    

            </div>  
        </div><br>
        <p class="text-center bg-ligth h4">Especializado en desarrollo de soluciones, de software y transformación de tus ideas a una plataforma digital, con enfoque de calidad y eficiencia.</p>
    </div>
</section>