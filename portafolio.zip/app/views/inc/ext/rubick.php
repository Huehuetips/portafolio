
<div class="my-loader" id="cube-structure">
  <div class="rubiks-cube" id="cube" style="color: red;">
    <div class="face front">
      <div style="background: #FFFFFF;" class="cube"></div> 
      <div style="background: #FFFFFF;" class="cube"></div>
      <div style="background: #FFFFFF;" class="cube"></div>
      <div style="background: #FFFFFF;" class="cube"></div>
      <div style="background: #FFFFFF;" class="cube"></div>
      <div style="background: #FFFFFF;" class="cube"></div>
      <div style="background: #FFFFFF;" class="cube"></div>
      <div style="background: #FFFFFF;" class="cube"></div>
      <div style="background: #FFFFFF;" class="cube"></div>
    </div>

    <div class="face back">
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
      <div style="background: #FFF600;" class="cube"></div>
    </div>
    <div class="face left">
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
      <div style="background: #18C10B;" class="cube"></div>
    </div>
    <div class="face right">
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
      <div style="background: #1800FF;" class="cube"></div>
    </div>
    <div class="face top">
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
      <div style="background: #FF8400;" class="cube"></div>
    </div>
    <div class="face bottom">
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
      <div style="background: #FF0000;" class="cube"></div>
    </div>
  </div>
</div>

