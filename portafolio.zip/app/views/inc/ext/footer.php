<footer class="text-center py-4 p-3 mb-2 bg-secondary text-white">
    <p>&copy; 2024 Mi Portafolio. Libre de Derechos.</p>
</footer>