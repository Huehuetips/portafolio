<?php 

	include_once "app/views/inc/ext/about.php";
	include_once "app/views/inc/ext/experiencia.php";
	include_once "app/views/inc/ext/proyectos.php";
	include_once "app/views/inc/ext/lenguajes.php";
	include_once "app/views/inc/ext/contacto.php";
	include_once "app/views/inc/ext/footer.php";
 ?>




