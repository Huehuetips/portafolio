<?php 

	$insLogin->sessionClose();


 ?>