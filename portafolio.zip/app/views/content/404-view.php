
 <div class="container py-5">
      <div class="row">
        <div class="col-md-2 text-center">
            <h1 class="display-3 fw-bold"><i class="bi bi-emoji-frown-fill"></i><br>404</h1>
        </div>
        <div class="col-md-10">
            <p class="fs-3"> <span class="text-danger">Lo sentimos!</span> Archivo No Encontrado.</p>
            <p>No se ha localizado la ruta solicitada.</p>
            <a class="btn btn-danger" href="javascript:history.back()">VOLVER</a>
        </div>
      </div>
 </div>