<?php 
	
	$url=$_POST['url'];
	header("location: ".$url);

 ?>