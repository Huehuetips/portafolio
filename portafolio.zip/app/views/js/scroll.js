// let ubicacion = window.pageYOffset;
// let nav = document.getElementById('nav')

// window.addEventListener('scroll', function () {
// 	let ubicacionAct =  window.pageYOffset;
// 	if (ubicacion>=ubicacionAct) {
// 		nav.style.top = "0px";
// 	}else{
// 		nav.style.top= "-80px";
// 	}

// 	ubicacion=ubicacionAct;
// })