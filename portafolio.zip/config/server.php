<?php 

	const DB_PORT=;
	const DB_SERVER="";
	const DB_NAME="";
	const DB_USER="";
	const DB_PASS="";

 ?>